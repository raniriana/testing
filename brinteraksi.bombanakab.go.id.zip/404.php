<?php header("HTTP/1.0 404 Not Found"); ?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
	<title>404 Not Found</title>
</head>
<body>
	<h1>Not Found</h1> 
	<p>The requested URL was not found on this server.</p> 
	<p>Additionally, a 404 Not Found error was encountered while trying to use an ErrorDocument to handle the request.</p> 
	<hr> 
	<address>Apache/2.2.22 (Unix) mod_ssl/2.2.22 OpenSSL/1.0.0-fips mod_auth_passthrough/2.1 mod_bwlimited/1.4 FrontPage/5.0.2.2635 Server at Port 80</address> 
</body>
</html>